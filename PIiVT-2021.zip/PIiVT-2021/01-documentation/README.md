Veb aplikacija za preged kataloga video igara

Projektni zahtev je kreiranje kataloga za video igre.
Koriscene tehnologije:ts/js/node.js/express/mysql

