export default interface IModel {
    
}