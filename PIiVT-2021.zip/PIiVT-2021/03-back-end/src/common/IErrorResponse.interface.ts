export default interface IErrorResponse {
    errorCode: number;
    errorMessage: string;
}